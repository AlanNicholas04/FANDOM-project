<?php

$mainNav = "<a href=/home.php > Home </a>|<a href=/media.php > Media </a>|<a href=/data.php> world info </a>|<a href=/form.php> contact the author </a>|<a href=/lore.php> Lore </a>" //"|<a href=/publicBoard.php> Fan Board </a>"
  ;
$footer = "Copyright and contact information";
$siteName= "Elemental Awakening Fandom <img src=/images/taco.jpg width='50' height='50'>";
$logo = "<img src=/images/taco.jpg>"
?>
<!-- NOTE: the taco image is not perminant, its just a place holder for the logo later on -->