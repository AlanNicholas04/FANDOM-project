<?php


header("Location: /publicBoard.php?fname=$fname&Message=$message&");
?>